package com.appproteam.sangha.bitdimo.View.CallBack;

import de.hdodenhof.circleimageview.CircleImageView;

public interface ChangeUserInformation {
    public void ChangeImageUser(CircleImageView userImage);
    public void EditUser();
}
