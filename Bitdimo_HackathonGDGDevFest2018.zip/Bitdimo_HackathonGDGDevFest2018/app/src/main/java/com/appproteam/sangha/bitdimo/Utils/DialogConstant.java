package com.appproteam.sangha.bitdimo.Utils;

public interface DialogConstant {
    public static final String YES_ACTION = "Yes";
    public static final String NO_ACTION = "No";
    public static final String OK_ACTION = "OK";
    public static final String ADD_DIAGLOG_NAME = "Adding";
    public static final String ADD_DIAGLOG_MESSAGE = "Add survey successfully";
    public static final String UPDATE_DIAGLOG_NAME = "Updating";
    public static final String UPDATE_DIAGLOG_MESSAGE = "Update survey successfully";

}
