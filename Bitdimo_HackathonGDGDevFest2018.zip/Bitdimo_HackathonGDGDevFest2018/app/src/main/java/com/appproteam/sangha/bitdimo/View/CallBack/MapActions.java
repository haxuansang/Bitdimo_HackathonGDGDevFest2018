package com.appproteam.sangha.bitdimo.View.CallBack;

public interface MapActions {
    void chooseRoad(int position);
}
