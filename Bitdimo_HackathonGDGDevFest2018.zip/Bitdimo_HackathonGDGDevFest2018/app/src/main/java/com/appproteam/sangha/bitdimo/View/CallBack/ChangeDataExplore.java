package com.appproteam.sangha.bitdimo.View.CallBack;

public interface ChangeDataExplore {
    void followTime();
    void followRating();
}
