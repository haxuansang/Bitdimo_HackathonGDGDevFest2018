package com.appproteam.sangha.bitdimo.Presenter.Objects;

public class ExplorePlace {
    String urlImage;
    public ExplorePlace(String urlImage)
    {
        this.urlImage=urlImage;
    }
    public String getUrlImage() {
        return urlImage;
    }

    public void setUrlImage(String urlImage) {
        this.urlImage = urlImage;
    }
}
