package com.appproteam.sangha.bitdimo.MultipleImagesSelector;


import com.appproteam.sangha.bitdimo.MultipleImagesSelector.models.ImageItem;

/**
 * Created by zfdang on 2016-4-12.
 */
public interface OnImageRecyclerViewInteractionListener {
    void onImageItemInteraction(ImageItem item);
}