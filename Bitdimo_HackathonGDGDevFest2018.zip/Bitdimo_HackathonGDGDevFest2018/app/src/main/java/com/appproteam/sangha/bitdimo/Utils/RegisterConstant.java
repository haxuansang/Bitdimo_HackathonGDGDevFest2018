package com.appproteam.sangha.bitdimo.Utils;


public interface RegisterConstant {
    public final static String COMFIRM_ERROR = "Nhập lại đúng với mật khẩu cũ";
}