package com.appproteam.sangha.bitdimo.Retrofit;

class UserResponse {
}
