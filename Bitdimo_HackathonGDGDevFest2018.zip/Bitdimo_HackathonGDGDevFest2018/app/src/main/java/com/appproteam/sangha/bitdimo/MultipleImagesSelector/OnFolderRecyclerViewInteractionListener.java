package com.appproteam.sangha.bitdimo.MultipleImagesSelector;


import com.appproteam.sangha.bitdimo.MultipleImagesSelector.models.FolderItem;


public interface OnFolderRecyclerViewInteractionListener {
    void onFolderItemInteraction(FolderItem item);
}
