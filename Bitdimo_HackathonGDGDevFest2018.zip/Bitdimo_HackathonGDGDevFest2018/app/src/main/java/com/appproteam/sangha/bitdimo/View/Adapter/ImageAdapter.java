package com.appproteam.sangha.bitdimo.View.Adapter;

public class ImageAdapter {
}
